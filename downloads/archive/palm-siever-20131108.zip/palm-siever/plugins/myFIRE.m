function myFIRE(handles)

X=getX(handles);
Y=getY(handles);
ss0=getSubset(handles);
res = getRes(handles);

iss0 = find(ss0);
iss0 = iss0(randperm(length(iss0)));

iss1 = iss0(1:end/2);
iss2 = iss0(end/2+1:end);

ss1 = false(size(ss0)); ss1(iss1)=true;
ss2 = false(size(ss0)); ss2(iss2)=true;

assignin('base','subset',ss1);
PALMsiever('bRedraw_Callback',[],[],handles)
D1 = getDensity(handles);

assignin('base','subset',ss2);
PALMsiever('bRedraw_Callback',[],[],handles)
D2 = getDensity(handles);

frcprofile=frc(cat(3,D1,D2));

r = inputdlg('Original image size (pixels) ');
imgSize = str2double(r{1});

[fire_value, ~, fireH, fireL] = postoresolution([X(ss) Y(ss)],res,res/imgSize);
logger(sprintf('FIRE value %2.1f +- %2.2f [px]\n', fire_value, (fireL-fireH)/2));

