function setZ(handles,Z)

assignin('base',handles.settings.varz,Z);
