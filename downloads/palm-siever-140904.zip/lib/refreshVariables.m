function handlesNew= refreshVariables(handles)
%replot and update based on any changes tothe workspace
handlesNew = PALMsiever('refreshVariables',handles);
