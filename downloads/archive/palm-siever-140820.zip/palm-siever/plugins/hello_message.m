% Simplest possible plugin example.
function hello_message(handles)

msgbox('Hello!!')

