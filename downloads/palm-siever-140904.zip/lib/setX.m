function setX(handles,X)

assignin('base',handles.settings.varx,X);
