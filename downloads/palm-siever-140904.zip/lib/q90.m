% q90 
function q = q90(x)

q = quantile(x,.9);
