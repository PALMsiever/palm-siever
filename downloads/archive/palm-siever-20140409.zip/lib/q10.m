% q10 
function q = q10(x)

q = quantile(x,.1);
