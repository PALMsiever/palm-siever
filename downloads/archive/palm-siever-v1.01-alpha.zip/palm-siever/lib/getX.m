function X = getX(handles)

X = fetch(handles.varx);
