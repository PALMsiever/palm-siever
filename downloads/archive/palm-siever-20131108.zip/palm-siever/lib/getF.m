function frame = getF(handles)

frame = fetch(handles.settings.varFrame);
