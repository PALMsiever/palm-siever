function Z = getZ(handles)

Z = fetch(handles.varz);
