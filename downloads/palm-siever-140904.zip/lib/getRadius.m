% Get the current radius
function R = getRadius(handles);

R=str2double(get(handles.radius,'String'));

