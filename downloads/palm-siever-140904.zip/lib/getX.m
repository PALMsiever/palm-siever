function X = getX(handles)

X = fetch(handles.settings.varx);
