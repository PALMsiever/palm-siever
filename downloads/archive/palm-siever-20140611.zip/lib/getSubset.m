function subset = getSubset(handles)

subset = fetch('subset');
