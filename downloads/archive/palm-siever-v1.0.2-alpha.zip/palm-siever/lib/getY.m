function Y = getY(handles)

Y = fetch(handles.vary);
