% Get the current radius
function L = getLength(handles);

L=str2double(get(handles.length,'String'));

