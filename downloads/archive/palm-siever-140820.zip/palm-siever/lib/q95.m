% q95 
function q = q95(x)

q = quantile(x,.95);
