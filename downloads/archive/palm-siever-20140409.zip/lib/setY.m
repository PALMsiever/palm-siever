function setY(handles,Y)

assignin('base',handles.settings.vary,Y);
