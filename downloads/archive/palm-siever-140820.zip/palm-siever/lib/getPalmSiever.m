function h = getPalmSiever(handles)

%h = getappdata(0,'self');
h = evalin('base','PS_FIGURE');
