function testColHash()

v1={'1','2','3','4'};
v2={'1','2','3','4','5','6'};
v3 = getColHash(v1,v2)
isempty(v3)

