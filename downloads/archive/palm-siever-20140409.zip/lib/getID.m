function frame = getID(handles)

frame = fetch(handles.settings.varID);
