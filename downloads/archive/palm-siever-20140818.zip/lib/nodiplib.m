function ndl = nodiplib()
ndl = getappdata(0,'usediplib')==false;
