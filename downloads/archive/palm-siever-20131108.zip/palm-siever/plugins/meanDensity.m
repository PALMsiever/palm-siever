function meanDensity(handles)



% Fetch the variables you need

X = getX(handles);

Y = getY(handles);

subset = getSubset(handles);



% Perform your calculations

rng = @(v) max(v(subset))-min(v(subset));

N = nnz(subset); 

md = N / (rng(X) * rng(Y));



% Output (to the log window)

logger('Mean density : ', md);



