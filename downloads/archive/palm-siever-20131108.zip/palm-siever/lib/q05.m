% q05
function q = q05(x)

q = quantile(x,.05);
